package com.example.levelupgamerx.data.local.remote

/**
 * Clase sellada (sealed class) que envuelve las respuestas de la API.
 * * Permite manejar tres estados posibles de una operación asíncrona de red:
 * 1. Cargando: La petición se ha iniciado.
 * 2. Éxito: La petición se completó correctamente y contiene datos de tipo [T].
 * 3. Error: La petición falló debido a problemas de red, HTTP, o de servidor.
 * * @param T El tipo de dato que se espera en caso de éxito.
 * *
 */
sealed class ResultadoApi<out T> {

    /**
     * Estado que indica que la petición se está procesando.
     */
    data object Cargando : ResultadoApi<Nothing>()

    /**
     * Estado que indica que la petición fue exitosa.
     * * @param datos Los datos de tipo [T] obtenidos de la API.
     */
    data class Exito<T>(val datos: T) : ResultadoApi<T>()

    /**
     * Estado que indica que hubo un error durante la petición.
     * * @param mensajeError Mensaje descriptivo del error para el usuario.
     * @param codigoHttp Código de estado HTTP del error (e.g., 404, 500).
     * @param excepcion La excepción real capturada (e.g., IOException por falta de red).
     */
    data class Error(
        val mensajeError: String,
        val codigoHttp: Int? = null,
        val excepcion: Exception? = null
    ) : ResultadoApi<Nothing>()
}

// ---------------------------------------------------------------------------------
// Extensiones de utilidad para manejar el ResultadoApi (Opcional pero muy útil)
// ---------------------------------------------------------------------------------

/**
 * Ejecuta una acción si el resultado es [Exito].
 */
inline fun <T> ResultadoApi<T>.onSuccess(action: (T) -> Unit): ResultadoApi<T> {
    if (this is ResultadoApi.Exito) {
        action(datos)
    }
    return this
}

/**
 * Ejecuta una acción si el resultado es [Error].
 */
inline fun <T> ResultadoApi<T>.onError(action: (mensaje: String, codigo: Int?, excepcion: Exception?) -> Unit): ResultadoApi<T> {
    if (this is ResultadoApi.Error) {
        action(mensajeError, codigoHttp, excepcion)
    }
    return this
}

/**
 * Ejecuta una acción si el resultado es [Cargando].
 */
inline fun <T> ResultadoApi<T>.onLoading(action: () -> Unit): ResultadoApi<T> {
    if (this is ResultadoApi.Cargando) {
        action()
    }
    return this
}