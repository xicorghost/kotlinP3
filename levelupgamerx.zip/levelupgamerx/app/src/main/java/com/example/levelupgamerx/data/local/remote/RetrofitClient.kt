package com.example.levelupgamerx.data.local.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Cliente Retrofit configurado como Singleton para manejo de peticiones HTTP
 *
 * Esta clase proporciona una instancia única de Retrofit para toda la aplicación.
 *
 * @author Sting Parra Silva (Referencia del proyecto de ejemplo)
 * @version 1.0
 */
object RetrofitClient {

    /**
     * URL base de la API REST de FakeStoreAPI
     * IMPORTANTE: Si usas tu propio servidor local, debes cambiar esta URL.
     * Ejemplo para emulador: "http://10.0.2.2:3000/"
     */
    private const val URL_BASE = "https://fakestoreapi.com/"

    /**
     * Interceptor para logging de peticiones y respuestas HTTP (Nivel BODY)
     * Muestra todo el JSON enviado y recibido en Logcat.
     */
    private val interceptorLog = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    /**
     * Cliente HTTP configurado con timeouts e interceptores
     */
    private val clienteHttp = OkHttpClient.Builder()
        .addInterceptor(interceptorLog)
        // Timeouts para evitar que la aplicación se congele
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Instancia de Retrofit inicializada de forma perezosa ('lazy')
     *
     * Hilt usa esta instancia en el [NetworkModule]
     */
    val instancia: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(URL_BASE)
            .client(clienteHttp)
            // Usa el conversor de Gson (debes tener la dependencia 'converter-gson')
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    /**
     * Crea una instancia del servicio API especificado
     * (Usado principalmente por Retrofit internamente o si no se usa Hilt)
     *
     * @param T Tipo del servicio API (interface)
     * @param servicioClase Clase del servicio a crear
     * @return Implementación del servicio API lista para usar
     */
    fun <T> crearServicio(servicioClase: Class<T>): T {
        return instancia.create(servicioClase)
    }
}