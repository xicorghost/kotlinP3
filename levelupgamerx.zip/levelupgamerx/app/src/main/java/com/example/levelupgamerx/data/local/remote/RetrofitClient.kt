package com.example.levelupgamerx.data.local.remote

class RetrofitClient {
}