package com.example.levelupgamerx.data.local.remote.dto

class ProductoDto {
}