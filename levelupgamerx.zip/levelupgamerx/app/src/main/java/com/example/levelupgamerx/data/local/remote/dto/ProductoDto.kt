package com.example.levelupgamerx.data.local.remote.dto

import com.example.levelupgamerx.domain.model.Producto
import com.google.gson.annotations.SerializedName

import com.example.levelupgamerx.domain.model.CategoriaProducto // Necesario para la transformación

/**
 * Data Transfer Object para Producto (Coincide con FakeStoreAPI)
 */
data class ProductoDto(
    @SerializedName("id")
    val identificador: Int,

    @SerializedName("title")
    val titulo: String,

    @SerializedName("description")
    val descripcion: String,

    @SerializedName("price")
    val precio: Double,

    @SerializedName("image")
    val urlImagen: String,

    // Este campo llega como String desde la API
    @SerializedName("category")
    val categoria: String
)

/**
 * Convierte un ProductoDto (API) a Producto (Dominio),
 * proporcionando valores por defecto o transformando los campos que faltan
 * en la API de FakeStore.
 */
fun ProductoDto.aModelo(): Producto {
    // 1. Convertir la categoría String de la API a tu Enum CategoriaProducto
    val categoriaEnum = CategoriaProducto.fromString(this.categoria)

    // 2. Generar un código único (ya que FakeStore no lo tiene)
    val codigoGenerado = "API-${this.identificador.toString().padStart(3, '0')}"

    return Producto(
        id = this.identificador,
        nombre = this.titulo,
        descripcion = this.descripcion,
        precio = this.precio,
        imagenUrl = this.urlImagen,

        // --- Campos faltantes en la API, asignados con lógica o por defecto ---
        codigo = codigoGenerado, // <-- Nuevo valor asignado
        categoria = categoriaEnum, // <-- Transformación de String a Enum
        stock = 10, // <-- Valor por defecto (como en el ejemplo del profesor)
        calificacionPromedio = 0f, // <-- Valor por defecto, ya que la API no da reseñas
        numeroResenas = 0 // <-- Valor por defecto
    )
}

/**
 * Convierte un Producto (Dominio) a ProductoDto (API)
 * Solo usamos los campos que la API de FakeStore espera para POST/PUT.
 */
fun Producto.aDto(): ProductoDto {
    return ProductoDto(
        identificador = this.id,
        titulo = this.nombre,
        descripcion = this.descripcion,
        precio = this.precio,
        urlImagen = this.imagenUrl,
        // Usar el displayName del Enum para enviarlo como String a la API
        categoria = this.categoria.displayName
    )
}

/**
 * Convierte una lista de ProductoDto a lista de Producto
 */
fun List<ProductoDto>.aModelos(): List<Producto> {
    return this.map { it.aModelo() }
}