package com.example.levelupgamerx.data.di

import android.content.Context
import androidx.room.Room
import com.example.levelupgamerx.data.local.AppDataBase // Tu clase de base de datos
import com.example.levelupgamerx.data.local.dao.ProductoDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDataBase {
        return Room.databaseBuilder(
            context,
            AppDataBase::class.java,
            "levelup_db" // Nombre de tu base de datos
        ).build()
    }

    /** Provee el DAO que necesita ProductoRepositoryImpl */
    @Provides
    fun provideProductoDao(appDatabase: AppDataBase): ProductoDao {
        return appDatabase.productoDao() // Método de AppDataBase para obtener el DAO
    }
}