package com.example.levelupgamerx.data.di

import com.example.levelupgamerx.data.local.remote.RetrofitClient
import com.example.levelupgamerx.data.local.remote.api.ProductoApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    /** Provee la instancia Singleton de Retrofit */
    @Provides
    @Singleton
    fun provideRetrofitInstance(): Retrofit {
        // Usa la instancia estática que ya tienes configurada
        return RetrofitClient.instancia
    }

    /** Provee la implementación de ProductoApiService */
    @Provides
    @Singleton
    fun provideProductoApiService(retrofit: Retrofit): ProductoApiService {
        // Hilt usará la instancia de Retrofit provista arriba
        return retrofit.create(ProductoApiService::class.java)
    }
}