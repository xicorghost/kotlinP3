/*package com.example.levelupgamerx.data.repository

import com.example.levelupgamerx.data.local.dao.ProductoDao
import com.example.levelupgamerx.data.local.entity.toEntity
import com.example.levelupgamerx.data.local.entity.toProducto
import com.example.levelupgamerx.domain.model.Producto
import com.example.levelupgamerx.domain.repository.RepositorioProductos
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import com.example.levelupgamerx.data.local.remote.api.ProductoApiService
// Imports de la API Service y ResultadoApi
import com.example.levelupgamerx.data.local.remote.ResultadoApi // Nuevo
import com.example.levelupgamerx.data.local.remote.dto.aModelos // Nuevo (para mapeo DTO -> Modelo)
import javax.inject.Inject

/**
 * Implementación del repositorio de productos gamer.
 * Traduce entre entidades de Room y modelos de dominio.
 */
class ProductoRepositoryImpl @Inject constructor(
    private val productoDao: ProductoDao
    private val productoApiService: ProductoApiService // AÑADIDO
) : RepositorioProductos {

    override fun obtenerProductos(): Flow<List<Producto>> {
        return productoDao.obtenerTodos().map { entities ->
            entities.map { it.toProducto() }
        }
    }

    override suspend fun obtenerProductoPorId(id: Int): Producto? {
        return productoDao.obtenerPorId(id)?.toProducto()
    }

    override suspend fun insertarProductos(productos: List<Producto>) {
        val entities = productos.map { it.toEntity() }
        productoDao.insertarLista(entities)
    }

    override suspend fun insertarProducto(producto: Producto): Long {
        return productoDao.insertar(producto.toEntity())
    }

    override suspend fun actualizarProducto(producto: Producto) {
        productoDao.actualizar(producto.toEntity())
    }

    override suspend fun eliminarProducto(producto: Producto) {
        productoDao.eliminar(producto.toEntity())
    }

    override suspend fun eliminarTodosLosProductos() {
        productoDao.eliminarTodos()
    }
    // Implementación de la nueva función para obtener productos de la API
    override suspend fun obtenerProductosRemotos(): ResultadoApi<List<Producto>> {
        return try {
            val respuesta = productoApiService.obtenerTodosLosProductos()

            if (respuesta.isSuccessful) {
                val productos = respuesta.body()?.aModelos() ?: emptyList()
                // Opcional: Insertar estos productos en la BD local para caché
                insertarProductos(productos)

                ResultadoApi.Exito(productos)
            } else {
                ResultadoApi.Error("Error HTTP: ${respuesta.code()}")
            }
        } catch (e: Exception) {
            ResultadoApi.Error("Fallo de conexión o parseo.", excepcion = e)
        }
    }
}*/
package com.example.levelupgamerx.data.repository

import com.example.levelupgamerx.data.local.dao.ProductoDao
import com.example.levelupgamerx.data.local.entity.toEntity
import com.example.levelupgamerx.data.local.entity.toProducto
import com.example.levelupgamerx.domain.model.Producto
import com.example.levelupgamerx.domain.repository.RepositorioProductos
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// --- CORRECCIÓN DE IMPORTS (data.remote en lugar de data.local.remote) ---
import com.example.levelupgamerx.data.local.remote.api.ProductoApiService
import com.example.levelupgamerx.data.local.remote.ResultadoApi
import com.example.levelupgamerx.data.local.remote.dto.aModelos
import javax.inject.Inject

/**
 * Implementación del repositorio de productos gamer.
 * Ahora maneja la BD local (Room) y la fuente remota (API).
 */
class ProductoRepositoryImpl @Inject constructor(
    private val productoDao: ProductoDao, // ¡CORRECCIÓN: Se añade la coma!
    private val productoApiService: ProductoApiService
) : RepositorioProductos {

    // --- Funciones de Room (Fuente de Verdad Local) ---

    override fun obtenerProductos(): Flow<List<Producto>> {
        return productoDao.obtenerTodos().map { entities ->
            entities.map { it.toProducto() }
        }
    }

    override suspend fun obtenerProductoPorId(id: Int): Producto? {
        return productoDao.obtenerPorId(id)?.toProducto()
    }

    override suspend fun insertarProductos(productos: List<Producto>) {
        val entities = productos.map { it.toEntity() }
        productoDao.insertarLista(entities)
    }

    override suspend fun insertarProducto(producto: Producto): Long {
        return productoDao.insertar(producto.toEntity())
    }

    override suspend fun actualizarProducto(producto: Producto) {
        productoDao.actualizar(producto.toEntity())
    }

    override suspend fun eliminarProducto(producto: Producto) {
        productoDao.eliminar(producto.toEntity())
    }

    override suspend fun eliminarTodosLosProductos() {
        productoDao.eliminarTodos()
    }

    // --- Función de la API (Sincronización) ---

    override suspend fun obtenerProductosRemotos(): ResultadoApi<List<Producto>> {
        return try {
            val respuesta = productoApiService.obtenerTodosLosProductos()

            if (respuesta.isSuccessful) {
                val productos = respuesta.body()?.aModelos() ?: emptyList()
                // Se insertan en Room, lo que dispara la actualización del Flow
                insertarProductos(productos)

                ResultadoApi.Exito(productos)
            } else {
                ResultadoApi.Error(
                    mensajeError = "Error HTTP ${respuesta.code()}",
                    codigoHttp = respuesta.code()
                )
            }
        } catch (e: Exception) {
            ResultadoApi.Error(
                mensajeError = "Fallo de conexión. Revise su conexión a Internet.",
                excepcion = e
            )
        }
    }
}