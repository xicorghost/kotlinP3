package com.example.levelupgamerx.data.local.remote.api

import com.example.levelupgamerx.data.local.remote.dto.ProductoDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Interface del servicio API para operaciones de productos
 *
 * Define todos los endpoints disponibles para interactuar con la API REST.
 * Retrofit genera automáticamente la implementación de esta interface en tiempo de ejecución.
 *
 * Todas las funciones son 'suspend' porque realizan operaciones de red asíncronas
 * que deben ejecutarse dentro de una coroutine.
 *
 * El tipo de retorno Response<T> envuelve el resultado y permite acceder a:
 * - Código de estado HTTP (200, 404, 500, etc.)
 * - Headers de la respuesta
 * - Cuerpo de la respuesta (body)
 * - Mensajes de error
 *
 *
 */
interface ProductoApiService {

    /**
     * Obtiene todos los productos disponibles en la API
     *
     * Endpoint: GET /products
     */
    @GET("products")
    suspend fun obtenerTodosLosProductos(): Response<List<ProductoDto>>

    /**
     * Obtiene un producto específico por su ID
     *
     * Endpoint: GET /products/{id}
     */
    @GET("products/{id}")
    suspend fun obtenerProductoPorId(
        @Path("id") identificador: Int
    ): Response<ProductoDto>

    /**
     * Obtiene productos filtrados por categoría
     *
     * Endpoint: GET /products/category/{categoria}
     */
    @GET("products/category/{categoria}")
    suspend fun obtenerProductosPorCategoria(
        @Path("categoria") nombreCategoria: String
    ): Response<List<ProductoDto>>

    /**
     * Obtiene la lista de todas las categorías disponibles
     *
     * Endpoint: GET /products/categories
     */
    @GET("products/categories")
    suspend fun obtenerCategorias(): Response<List<String>>

    /**
     * Obtiene un número limitado de productos
     *
     * Endpoint: GET /products?limit={cantidad}
     */
    @GET("products")
    suspend fun obtenerProductosConLimite(
        @Query("limit") limite: Int
    ): Response<List<ProductoDto>>

    /**
     * Obtiene productos ordenados
     *
     * Endpoint: GET /products?sort={orden}
     */
    @GET("products")
    suspend fun obtenerProductosOrdenados(
        @Query("sort") orden: String = "asc"
    ): Response<List<ProductoDto>>

    /**
     * Crea un nuevo producto en la API
     *
     * Endpoint: POST /products
     */
    @POST("products")
    suspend fun agregarProducto(
        @Body nuevoProducto: ProductoDto
    ): Response<ProductoDto>

    /**
     * Actualiza un producto existente (reemplazo completo)
     *
     * Endpoint: PUT /products/{id}
     */
    @PUT("products/{id}")
    suspend fun modificarProducto(
        @Path("id") identificador: Int,
        @Body productoActualizado: ProductoDto
    ): Response<ProductoDto>

    /**
     * Elimina un producto de la API
     *
     * Endpoint: DELETE /products/{id}
     */
    @DELETE("products/{id}")
    suspend fun borrarProducto(
        @Path("id") identificador: Int
    ): Response<Unit>

    /**
     * Obtiene productos con múltiples filtros
     *
     * Endpoint: GET /products?limit={limite}&sort={orden}
     */
    @GET("products")
    suspend fun obtenerProductosFiltrados(
        @Query("limit") limite: Int,
        @Query("sort") orden: String
    ): Response<List<ProductoDto>>
}