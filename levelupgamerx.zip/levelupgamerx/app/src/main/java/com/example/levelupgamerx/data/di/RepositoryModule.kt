package com.example.levelupgamerx.data.di

import com.example.levelupgamerx.data.local.dao.ProductoDao
import com.example.levelupgamerx.data.local.remote.api.ProductoApiService
import com.example.levelupgamerx.data.repository.ProductoRepositoryImpl
import com.example.levelupgamerx.domain.repository.RepositorioProductos
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.ViewModelComponent // Usar ViewModelComponent para Repositorios
import dagger.hilt.android.scopes.ViewModelScoped // Ámbito de vida del ViewModel
import javax.inject.Singleton

@Module
@InstallIn(ViewModelComponent::class)
object RepositoryModule {

    /**
     * Provee la implementación del Repositorio de Productos.
     * Hilt resuelve automáticamente las dependencias (ProductoDao y ProductoApiService).
     */
    @Provides
    @ViewModelScoped // El repositorio vive mientras viva el ViewModel que lo usa
    fun provideProductoRepository(
        // Hilt buscará ProductoDao (desde el DatabaseModule)
        productoDao: ProductoDao,
        // Hilt buscará ProductoApiService (desde el NetworkModule)
        productoApiService: ProductoApiService
    ): RepositorioProductos {
        // Retorna la implementación con sus dependencias
        return ProductoRepositoryImpl(productoDao, productoApiService)
    }
}